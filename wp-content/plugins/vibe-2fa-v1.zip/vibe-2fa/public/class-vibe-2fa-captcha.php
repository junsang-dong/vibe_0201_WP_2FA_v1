<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vibe_2FA_Captcha {
	private $plugin;

	public function __construct( Vibe_2FA $plugin ) {
		$this->plugin = $plugin;
	}

	public function hooks() {
		add_action( 'login_form', array( $this, 'render_login_field' ) );
	}

	public function render_login_field() {
		$options = $this->plugin->get_options();
		if ( empty( $options['enable_captcha'] ) ) {
			return;
		}
		?>
		<p>
			<label for="vibe_2fa_captcha"><?php esc_html_e( '캡차 확인', 'vibe-2fa' ); ?></label>
			<input type="text" name="vibe_2fa_captcha" id="vibe_2fa_captcha" class="input" value="" size="20" />
			<span class="description"><?php esc_html_e( '스켈레톤 단계: 임의의 텍스트를 입력하세요.', 'vibe-2fa' ); ?></span>
		</p>
		<?php
	}

	public function validate_request() {
		$options = $this->plugin->get_options();
		if ( empty( $options['enable_captcha'] ) ) {
			return true;
		}

		if ( ! isset( $_POST['log'] ) || ! isset( $_POST['pwd'] ) ) {
			return true;
		}

		if ( isset( $_POST['action'] ) && 'vibe_2fa' === $_POST['action'] ) {
			return true;
		}

		$value = isset( $_POST['vibe_2fa_captcha'] ) ? sanitize_text_field( wp_unslash( $_POST['vibe_2fa_captcha'] ) ) : '';
		$valid = '' !== $value;

		return (bool) apply_filters( 'vibe_2fa_captcha_valid', $valid, $value );
	}
}
